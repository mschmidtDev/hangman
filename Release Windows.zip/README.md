# hangman
Hangman Project for school

Release Windows instructions:

1.  Download Release Windows.rar
2.  Unzip it
3.  Execute hangman.exe

Release MAC instructions:

1.  Download Release Mac.zip
2.  Unzip it
3.  Run a CMD tool in that folder
4.  Run "make" and then "make clean"
5.  Run "./hangman" or double-click the hangman executable

To anyone who reads this, here are some tips for this program

1.  If you want to compile it using code::blocks, you might need to re-add all .c and
    .h files in order for code::blocks to link them properly.

2.  If you delete the usernames.txt, or manipulate it by hand, there definetly WILL be
    funky outputs when choosing a username. You can only save 3 usernames and should do it
    via the program.

3.  Yes, the encryption on the .txt is one of the easiest to crack, but it was set in the specification,
